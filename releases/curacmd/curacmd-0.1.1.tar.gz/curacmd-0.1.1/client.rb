local_mode true
chef_zero.enabled true
local_mode true
node_name "curalate-laptop"

cache_path "/Users/bchen/.chef/local-mode-cache/"
chef_repo_path "/Users/bchen/Git/Curalate/curacmd/"
