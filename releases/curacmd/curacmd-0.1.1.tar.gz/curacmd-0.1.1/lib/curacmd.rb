require 'logger'
require 'optparse'

require_relative 'project.rb'
require_relative 'task.rb'

class CuraCmd

  attr_accessor :my_project, :my_tasks, :loglevel
  attr_reader :logger, :projects

  public
  def initialize(options, loglevel = 'debug')
    # Always do first
    init_logger(loglevel)

    # Do project discovery
    @projects = CuraCmd::Project.discover

    # Initialize the run based on parameters
    init_params(options)
  end

  def run
    # TODO: support dry-run and other run options
    build_run_list()
    @logger.debug(@run_list)
    @logger.info("Invoking Chef...\n")
    run_chef()
    puts("")
    @logger.info("Chef Run Complete!")
  end

  protected
  def build_run_list
    @run_list = @my_tasks.map do |t|
      t = "recipe[#{@my_project.name}::#{t.name}]"
    end
    @run_list = @run_list.join(',')
  end

  def init_logger(loglevel)
    @logger = Logger.new(STDOUT)
    #TODO: try/catch the Logger.const_get and throw a WARN?
    #TODO: probably better to do it in optparse tho?
    @loglevel = Logger.const_get(loglevel.upcase)
    @logger.level = @loglevel
    @logger.datetime_format = "%Y-%m-%d %H:%M:%S"
    @logger.formatter = proc do |severity, datetime, progname, msg|
      "[#{datetime}] #{severity}: #{msg}\n"
    end
    @logger.debug("Logger initialized")
  end

  def init_params(options)
    init_project(options['project'])
    init_tasks(options['tasks'])
  end

  private
  def run_chef
    # TODO: Support noop run and other such things somewhere
    # TODO: Format output with block_given? and yield
    system("/usr/local/bin/chef-client --config ~/Git/Curalate/curacmd/client.rb --runlist '#{@run_list}'")
  end

  def init_project(p)
    @logger.debug("Found the following Projects: #{project_names.inspect}")

    # Project Validation and Creation
    if valid_project?(p)
      # Creates instances of project
      @my_project = CuraCmd::Project.new(p)
      @logger.debug("Project: #{@my_project.name} exists")
    else
      # Log an error and exit
      @logger.error("Project: #{p} does not exist, exiting...")
      exit 1
    end
    @logger.debug("Project: #{@my_project.name} has the following tasks: #{@my_project.task_names.inspect}")
  end

  def init_tasks(tasks)
    # Task Validation and Creation
    task_list = tasks.split(',')
    @logger.debug("Requested Task Run List: #{task_list.inspect}")
    @my_tasks = []
    task_list.each do |t|
      if (valid_task?(t))
        @logger.debug("Found Task: #{t} in Project: #{@my_project.name}, adding to runlist")
        # Pull the Task Object directly from the instantiated @my_project object tasks list
        @my_tasks << @my_project.tasks.select { |pt| t == pt.name }.first
      else
        @logger.error("Task: #{t} does not exist in Project: #{@my_project.name}")
        exit 1
      end
    end
  end

  def project_names
    names = @projects.map do |p|
      p = p.name
    end
    names
  end

  def valid_project?(p)
    if project_names.include?(p)
      true
    else
      false
    end
  end

  def valid_task?(t)
    # TODO: Iterate through task list
    if (@my_project.task_names.include?(t))
      true
    else
      false
    end
  end

end
