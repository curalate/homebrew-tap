class CuraCmd

  class Task

    attr_reader :name, :project, :metadata

    public
    def initialize(name, project)
      # (String) Name of the task
      @name = name
      # (String) Project this task belongs to
      @project = project
      init_metadata()
    end

    # Static Methods
    def self.discover(project)
      # Static Method to discover tasks
      tasks = self.get_tasks(project)
      return tasks
    end

    protected
    def init_metadata()
      # TODO: Stub
      # Attempt to parse project metadata
      mydir = __dir__
      path = "#{mydir}/../cookbooks/#{@project}/metadata.yaml"
      begin
        metadata = YAML.load_file(path)
      rescue Errno::ENOENT
        # No metadata file
        metadata = {}
        metadata[@name] = {}
        metadata[@name]['discoverable'] = true
        metadata[@name]['description'] = 'Missing metadata.yaml file'
      rescue Psych::SyntaxError
        # Mangled YAML
        metadata = {}
        metadata[@name] = {}
        metadata[@name]['discoverable'] = true
        metadata[@name]['description'] = 'Mangled metadata.yaml file'
      end
      metadata = metadata[@name]
      if metadata
        @metadata = metadata
      else
        @metadata = {}
      end
    end

    # Static Methods
    def self.get_tasks(project)
      mydir = __dir__
      # Grab all the rb files
      results = Dir.glob("#{mydir}/../cookbooks/#{project}/recipes/*.rb")
      recipes = results.select do |result|
        File.file?(result)
      end
      tasks = recipes.map do |recipe|
        recipe.split("/").last.rpartition(".rb").first
      end
      tasks.map do |t|
        t = CuraCmd::Task.new(t, project)
      end
    end
  end

end
