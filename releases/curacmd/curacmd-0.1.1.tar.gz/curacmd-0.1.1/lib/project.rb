require 'yaml'

require_relative 'task.rb'

class CuraCmd

  class Project

    attr_reader :name, :tasks, :metadata

    public
    def initialize(name)
      # TODO: Stubby stub
      @name = name
      @tasks = CuraCmd::Task.discover(@name)
      init_metadata()
    end

    def task_names
      n = @tasks.map do |t|
        t = t.name
      end
      n
    end
    
    # Static Methods
    def self.discover
      # Static Method to discover projects
      # TODO: Should return a list of instances of Project
      projects = self.get_projects('.')
      return projects
    end

    protected
    def init_metadata()
      # Attempt to parse project metadata
      mydir = __dir__
      path = "#{mydir}/../cookbooks/#{@name}/metadata.yaml"
      begin
        metadata = YAML.load_file(path)
      rescue Errno::ENOENT
        # No metadata file
        metadata = {}
        metadata['project'] = {}
        metadata['project']['discoverable'] = true
        metadata['project']['description'] = 'Missing metadata.yaml file'
      rescue Psych::SyntaxError
        # Mangled YAML
        metadata = {}
        metadata['project'] = {}
        metadata['project']['discoverable'] = true
        metadata['project']['description'] = 'Mangled metadata.yaml file'
      end
      metadata = metadata['project']
      if metadata
        @metadata = metadata
      else
        @metadata = {}
      end
    end

    # Static Methods
    def self.get_projects(directory)
      # TODO: Return list of Project instances
      mydir = __dir__
      # Grab all the cookbooks
      results = Dir.glob("#{mydir}/../cookbooks/*")
      # Filter for dirs only
      dirs = results.select do |result|
        File.directory?(result)
      end
      project_names = dirs.map do |dir|
        dir.split('/').last
      end
      projects = project_names.map do |project|
        project = CuraCmd::Project.new(project)
      end
      projects
    end

  end

end
