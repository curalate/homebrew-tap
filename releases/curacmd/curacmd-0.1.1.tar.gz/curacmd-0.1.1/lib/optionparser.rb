require 'logger'
require 'optparse'

class CuraCmd

  class OptionParser
    attr_reader :parser, :params

    public
    def initialize
      @params = {}
      init_parser()
    end

    def parse!
      begin
        @parser.parse!
      rescue ::OptionParser::MissingArgument
        # Just catching exceptions if the user doesn't specify an argument to
        # a parameter.  Just looks prettier than stack output
        puts @parser
        exit 1
      end
    end

    protected
    def init_parser
      @parser = ::OptionParser.new do |opt|
        opt.banner =  'Usage: '
        opt.separator '       curacmd -p <project> -t <tasks>'
        opt.separator 'Parameters:'

        opt.on('-d', '--discover', "Show me things I can do") do |value|
          @params['discover'] = value
        end

        opt.on('-p <PROJECT>', '--project <PROJECT>', 'project to invoke your tasks against') do |value|
          @params['project'] = value
        end

        opt.on('-t <TASKS>', '--tasks <TASK1,TASK2,etc...>', 'comma separated tasks to invoke within that project') do |value|
          @params['tasks'] = value
        end
      end
    end
  end

end
