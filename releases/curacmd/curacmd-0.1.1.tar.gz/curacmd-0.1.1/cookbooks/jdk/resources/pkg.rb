# Cookbook Name:: jdk
# Provider:: pkg

# Actions
actions :install
default_action :install

attribute :path_to_pkg, :name_attribute => true, :kind_of => String, 
          :required => true

attribute :version, :kind_of => String, :default => "7"
attribute :update, :kind_of => String, :default => "79"
attribute :force_install, :kind_of => [TrueClass, FalseClass], :default => false

attr_accessor :installed
