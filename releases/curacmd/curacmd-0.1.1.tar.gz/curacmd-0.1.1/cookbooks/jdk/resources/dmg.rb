# Cookbook Name:: jdk
# Provider:: dmg

# Actions
actions :mount, :umount
default_action :mount

attribute :path_to_dmg, :name_attribute => true, :kind_of => String, 
          :required => true

attr_accessor :mounted
