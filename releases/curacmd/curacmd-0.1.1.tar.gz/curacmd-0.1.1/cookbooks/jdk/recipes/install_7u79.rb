#
# Cookbook Name:: jdk
# Recipe:: install_7u79
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

jdk_version = "7"
jdk_update = "79"
dmg_checksum = "b52bcac56440e7fd0b5db9e331d31d2bd458f588b8b01e52eaf0ad2affaf9da2"

remote_file "/Users/#{node['current_user']}/Downloads/jdk-#{jdk_version}u#{jdk_update}-macosx-x64.dmg" do
  action :create
  source "file:///Users/#{node['current_user']}/Documents/Curalate/java/jdk-#{jdk_version}u#{jdk_update}-macosx-x64.dmg"
  checksum "#{dmg_checksum}"
  mode '0644'
end

jdk_dmg "mount_dmg" do
  action "mount"
  path_to_dmg "/Users/#{node['current_user']}/Downloads/jdk-#{jdk_version}u#{jdk_update}-macosx-x64.dmg"
end

jdk_pkg "install_jdk#{jdk_version}u#{jdk_update}" do
  action "install"
  path_to_pkg "/Volumes/JDK #{jdk_version} Update #{jdk_update}/JDK #{jdk_version} Update #{jdk_update}.pkg"
  version "#{jdk_version}"
  update "#{jdk_update}"
end

jdk_dmg "unmount_dmg" do
  action "umount"
  path_to_dmg "/Users/#{node['current_user']}/Downloads/jdk-#{jdk_version}u#{jdk_update}-macosx-x64.dmg"
end
