# Cookbook Name:: jdk
# Provider:: pkg

require 'plist'

include Chef::Mixin::ShellOut

# Chef Provider Interface Methods
def whyrun_supported?
  # Return true if you support whyrun / no-op
  # Code that creates resources need to implement a converge_by block
  true
end

def load_current_resource
  # Instantiates a new resource based on the requested resource
  @current_resource = Chef::Resource::JdkPkg.new(@new_resource.name)

  # Sets the resource to have the same properties
  @current_resource.name(@new_resource.name)
  @current_resource.path_to_pkg(@new_resource.path_to_pkg)
  @current_resource.version(@new_resource.version)
  @current_resource.update(@new_resource.update)
  @current_resource.force_install(@new_resource.force_install)

  # Checks if the resource exists
  if installed?
    @current_resource.installed = true
  end
end

# Chef Action Definitions
action :install do
  if @current_resource.installed
    # Checks if attempt to create this new resource is already in existence
    # Logs a message
    # Checks the force_install parameter.  If it's true install anyway
    if @new_resource.force_install
      converge_by("#{@new_resource} is already installed but, force install requested") do
        install_pkg(@new_resource.path_to_pkg)
      end
    else
      Chef::Log.info "#{@new_resource} is already installed - nothing to do."
    end
  else
    # If resource does not exist, invoke the converge_by block
    converge_by("Install #{@new_resource}") do
      # Invoke method to create new resource
      install_pkg(@new_resource.path_to_pkg)
    end
  end
end

# Custom Functions
def installed?
  # Code to check if the package is installed
  jdk_version = @new_resource.version
  jdk_update = @new_resource.update
  get_pkg_list.include?("com.oracle.jdk#{jdk_version}u#{jdk_update}")
end

def install_pkg(path_to_pkg)
  # Code to actually install the pkg
  # In case you are wondering about this
  # \\\"#{path_to_pkg}\\\"
  # escaping the escaped to prevent osascript from blowing up since it needs
  # double quotes oh osascript -e, you are so cruel
  run_with_admin("/usr/sbin/installer -pkg \\\"#{path_to_pkg}\\\" -target /")
end

def get_pkg_list
  pkg_list_cmd = shell_out("pkgutil --pkgs-plist")
  Plist::parse_xml(pkg_list_cmd.stdout)
end

def run_with_admin(command)
  shell_out!("/usr/bin/osascript -e 'do shell script \"#{command}\" with administrator privileges'")
end
