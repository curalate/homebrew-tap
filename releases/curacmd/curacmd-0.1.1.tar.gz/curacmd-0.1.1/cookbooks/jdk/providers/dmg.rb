# Cookbook Name:: jdk
# Provider:: dmg

require 'plist'

include Chef::Mixin::ShellOut

# Chef Provider Interface Methods
def whyrun_supported?
  # Return true if you support whyrun / no-op
  # Code that creates resources need to implement a converge_by block
  true
end

def load_current_resource
  # Instantiates a new Java DMG Resource based
  @current_resource = Chef::Resource::JdkDmg.new(@new_resource.name)

  # Sets the Java DMG Resource to have the same properties
  @current_resource.name(@new_resource.name)
  @current_resource.path_to_dmg(@new_resource.path_to_dmg)

  # Checks if the Java DMG resource is already mounted
  if mounted?
    @current_resource.mounted = true
  end
end

# Chef Action Definitions
action :mount do
  if @current_resource.mounted
    # Checks if attempt to create this new resource is already in existence
    # Logs a message
    Chef::Log.info "#{@new_resource} is already mounted - nothing to do."
  else
    # If resource does not exist, invoke the converge_by block
    converge_by("Mount #{@new_resource}") do
      # Invoke method to create new resource
      mount_dmg(@new_resource.path_to_dmg)
    end
  end
end

action :umount do
  # Checks if the DMG is mounted
  # Can only umount if it is currently mounted
  if @current_resource.mounted
    converge_by("Unmount #{@new_resource}") do
      umount_dmg(@new_resource.path_to_dmg)
    end
  else
    Chef::Log.info "#{@new_resource } is not mounted - nothing to do."
  end
end

# Custom Functions
def mounted?
  # Code to check if the directory exists and is already mounted
  dmg_mounts = get_dmg_mounts(@new_resource.path_to_dmg)
  dmg_mounts.length > 0
end

def mount_dmg(path_to_dmg)
  # Code to actually mount the dmg
  # TODO: Log some info
  shell_out!("hdiutil attach #{path_to_dmg}")
end

def umount_dmg(path_to_dmg)
  # Code to actually unmount the dmg
  # TODO: Log some info

  # Get a list of all mounted instances of that DMG
  dmg_mounts = get_dmg_mounts(path_to_dmg)
  # Iterate through each mounted instance
  dmg_mounts.each do |dmg_mount|
    # Grab the system meta-data that tells us where it's mounted
    system_entities = dmg_mount['system-entities'].select do |entity|
      entity.has_key?('mount-point')
    end
    # Iterate through all umount them
    system_entities.each do |entity|
      shell_out("hdiutil detach #{entity['dev-entry']} || hdiutil detach #{entity['dev-entry']} -force")
    end
  end
end

def get_dmg_mounts(path_to_dmg)
  # Grabs plist of all mounted volumes
  hdiutil_cmd = shell_out("hdiutil info -plist")
  
  # Parse plist and grabs all mounted images
  data = Plist::parse_xml(hdiutil_cmd.stdout)
  images = data['images']

  # Grabs list of mounted volumes that match the image parameter
  images.select { |image| image['image-path'] == path_to_dmg }
end
