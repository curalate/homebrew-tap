# CuraCmd
Curalate command line tools for da laptop.  Wrapper on our OSX cookbook repo to
make it easier to do stuff

## Installation and Execution for Dev
* Install bundle into your RVM or system Ruby. `sudo gem install bundle`
* From within this git repo, run: `bundle install --path .bundle`
* Tweak the config file for now `client.rb` to match your cache path and repo path
* Run it!  It only does one thing right now `bundle exec ruby curacmd -p jdk -t install_7u79`
